import yaml
import time
import rcon
import requests

class StreamBot:
    def __init__(self):
        self.load_config()
        self.subscriber_count = 0
        self.like_count = 0
        self.viewer_count = 0
        self.cooldown_subscribe = self.config['cooldown']['subscribe']
        self.cooldown_like = self.config['cooldown']['like']
        self.youtube_api_key = self.config['youtube']['api_key']
        self.live_id = self.config['youtube']['live_id']

    def load_config(self):
        with open('config.yml', 'r') as file:
            self.config = yaml.safe_load(file)

    def get_youtube_live_stats(self):
        url = f"https://www.googleapis.com/youtube/v3/videos?part=statistics&id={self.live_id}&key={self.youtube_api_key}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            stats = data['items'][0]['statistics']
            self.subscriber_count = int(stats.get('subscriberCount', 0))
            self.like_count = int(stats.get('likeCount', 0))
            self.viewer_count = int(stats.get('viewCount', 0))
        else:
            print("Error fetching YouTube data:", response.content)

    def update_live_stats(self):
        self.get_youtube_live_stats()  # Fetch YouTube stats
        action_bar_message = self.config['messages']['action_bar'].format(
            subs=self.subscriber_count,
            likes=self.like_count,
            viewers=self.viewer_count
        )
        self.send_action_bar(action_bar_message)

    def send_action_bar(self, message):
        # Implement your RCON logic to send a message to the Minecraft server
        with rcon.Client(self.config['rcon']['ip'], self.config['rcon']['port'], self.config['rcon']['password']) as client:
            client.run(f"tell {self.config['players']['main_player']} {message}")

    def on_subscribe(self):
        time.sleep(self.cooldown_subscribe)  # Simulating cooldown
        with rcon.Client(self.config['rcon']['ip'], self.config['rcon']['port'], self.config['rcon']['password']) as client:
            client.run(self.config['commands']['on_subscribe'])
            self.update_live_stats()

    def on_like(self):
        time.sleep(self.cooldown_like)  # Simulating cooldown
        with rcon.Client(self.config['rcon']['ip'], self.config['rcon']['port'], self.config['rcon']['password']) as client:
            client.run(self.config['commands']['on_like'])
            self.update_live_stats()

    def start(self):
        # Simulate the bot running and responding to events
        while True:
            # Here you would have logic to check for actual subscribe/like events
            # For now, we'll simulate them
            self.on_subscribe()
            self.on_like()
            time.sleep(5)  # Wait before the next event

if __name__ == "__main__":
    bot = StreamBot()
    bot.start()
