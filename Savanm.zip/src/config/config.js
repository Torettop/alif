export class Config {
    static TELEGRAM_APP_ID = undefined; // YOUR APP ID
    static TELEGRAM_APP_HASH = undefined; // YOUR APP HASH
  }