package com.alif.alifplugin;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class AlifPlugin extends JavaPlugin {
    
    private YouTubeAPI youTubeAPI;
    
    @Override
    public void onEnable() {
        saveDefaultConfig();
        youTubeAPI = new YouTubeAPI(this);
        
        // Start the task to fetch YouTube stats
        new BukkitRunnable() {
            @Override
            public void run() {
                youTubeAPI.checkLiveStats();
            }
        }.runTaskTimer(this, 0, 1200); // Check every 60 seconds
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}