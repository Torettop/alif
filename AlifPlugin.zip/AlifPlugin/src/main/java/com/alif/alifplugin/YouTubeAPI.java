package com.alif.alifplugin;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class YouTubeAPI {

    private final JavaPlugin plugin;
    private int lastSubscriberCount = 0;

    public YouTubeAPI(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void checkLiveStats() {
        FileConfiguration config = plugin.getConfig();
        String apiKey = config.getString("youtube.api_key");
        String channelId = config.getString("youtube.channel_id");

        try {
            URL url = new URL("https://www.googleapis.com/youtube/v3/channels?part=statistics&id=" + channelId + "&key=" + apiKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Parse the JSON response to get subscriber count, likes, and views
            // (Use a JSON library like Gson or Jackson to parse this)

            int currentSubscriberCount = parseSubscriberCount(response.toString());

            if (currentSubscriberCount != lastSubscriberCount) {
                lastSubscriberCount = currentSubscriberCount;
                // Execute command on subscription event
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), config.getString("commands.on_subscribe"));
                
                // Broadcast the live status message
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendMessage(config.getString("messages.live_status")
                        .replace("%subscribers%", String.valueOf(currentSubscriberCount))
                        .replace("%likes%", "0") // Placeholder, you should retrieve actual likes
                        .replace("%views%", "0")); // Placeholder, you should retrieve actual views
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int parseSubscriberCount(String jsonResponse) {
        // Implement JSON parsing logic here (e.g., using Gson or Jackson)
        // Return the subscriber count
        return 0; // Replace with actual parsing
    }
}
